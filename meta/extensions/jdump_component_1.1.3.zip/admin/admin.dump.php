<?php
/**
 * J!Dump
 * @version      $Id: admin.dump.php 34 2011-01-04 14:48:04Z mjaz $
 * @package      mjaztools_dump
 * @copyright    Copyright (C) 2007 J!Dump Team. All rights reserved.
 * @license      GNU/GPL
 * @link         http://joomlacode.org/gf/project/jdump/
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

// use JPATH_COMPONENT_ADMINISTRATOR so we can use this in both site and administrator
// Defines
require_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'defines.php' );
// Require the base controller
require_once( JPATH_COMPONENT_ADMINISTRATOR . DS . 'controller.php' );

// Require specific controller if requested
if( $controller = JRequest::getCmd('controller') ) {
    require_once ( JPATH_COMPONENT_ADMINISTRATOR . DS . 'controllers' . DS . $controller . '.php' );
}

// Create the controller
$classname  = 'DumpController'.$controller;
$controller = new $classname();

// Perform the Request task
$controller->execute( JRequest::getCmd( 'task' ) );

$controller->redirect();
