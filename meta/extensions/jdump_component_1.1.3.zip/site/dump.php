<?php
/**
 * J!Dump
 * @version      $Id: dump.php 31 2008-04-28 14:46:40Z jenscski $
 * @package      mjaztools_dump
 * @copyright    Copyright (C) 2007 J!Dump Team. All rights reserved.
 * @license      GNU/GPL
 * @link         http://joomlacode.org/gf/project/jdump/
 */
defined( '_JEXEC' ) or die( 'Restricted access' );

//load the administrator component
require( JPATH_COMPONENT_ADMINISTRATOR . DS . 'admin.dump.php' );
