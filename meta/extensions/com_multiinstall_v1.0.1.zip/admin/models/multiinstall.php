<?php
/**
* Copyright (C) 2010  Chris Taylor www.forgetso.com (cjtaylor38@gmail.com)
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
// no direct access
defined('_JEXEC') or die(';)');
jimport('joomla.application.component.model');
jimport('joomla.filesystem.folder');
/**
* Settings Model
*
* @package    MultiInstall
* @subpackage Models
*/
class MultiInstallModelMultiInstall extends JModel {
    function upload() {
        set_time_limit(0);
        $extfile = JRequest :: getVar('extfile', null, 'files', 'array');
        $folder = JPATH_SITE.'/tmp/multiinstall';

        if(JFolder::exists($folder)) {
            JFolder::delete($folder);
        }
        JFolder::create($folder);
        $link = 'index.php?option=com_multiinstall';
        $mainframe = & JFactory::getApplication();
        if(class_exists('ZipArchive')) {
            $zip = new ZipArchive;
            if ($zip->open($extfile['tmp_name']) === TRUE) {
                $zip->extractTo($folder);
                $zip->close();
                $pkgs = JFolder::files($folder);
                $this->installExtensions($pkgs);
            }
            else {

                $msg = JText::_('UNZIPERROR');
                $mainframe->redirect($link, $msg);
            }
        }
        else {
            $msg = JText::_('ERRORZIPCLASS');
            $mainframe->redirect($link, $msg);
        }
    }

    function installExtensions($pkgs) {
        jimport('joomla.installer.helper');
        jimport('joomla.installer.installer');
        $installer = new JInstaller();
        $installer->_overwrite = true;
        $pkg_path = JPATH_SITE.'/tmp/multiinstall/';
        $mainframe = & JFactory :: getApplication();
        foreach ($pkgs as $pkg) {
            $package = JInstallerHelper :: unpack($pkg_path . $pkg);
            if ($installer->install($package['dir'])) {
                $msg = 1;
            } else {
                $msg = 0;
                $msgtext = JText::sprintf("INSTALLERROR", $pkg);
            }
            if (!$msg) {
                $mainframe->redirect('index.php?option=com_multiinstall', $msgtext);
            }
        }
        if (JFolder :: exists($pkg_path)) {
            JFolder :: delete($pkg_path);
        }
        $msg = JText::sprintf('INSTALLSUCCESS',count($pkgs));
        $mainframe->redirect('index.php?option=com_multiinstall', $msg);
    }
}