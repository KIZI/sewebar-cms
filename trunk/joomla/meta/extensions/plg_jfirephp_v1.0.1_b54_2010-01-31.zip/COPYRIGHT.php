<?php
/**
* @version $Id: COPYRIGHT.php 1812 2010-01-30 16:31:33Z fxstein $
* Kunena Component
* @package Kunena
*
* @Copyright (C) 2008 - 2009 Kunena Team All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.com
*/

// no direct access
defined( '_JEXEC' ) or die();
?>

<!--

JFirePHP includes or is derivative of works distributed under the following copyright notices:

F  i  r  e  P  H  P  C  o  r  e
---
Copyright:  Christoph Dorn <christoph@christophdorn.com>
  			Michael Day    <manveru.alma@gmail.com>

License:	BSD Open-Source License

-->