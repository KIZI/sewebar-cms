<?php
/**
* @version $Id: CHANGELOG.php 1827 2010-01-31 03:50:03Z fxstein $
* MyKunena Plugin
* @package MyKunena
*
* @Copyright (C) 2010 www.kunena.com All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.com
*/

// no direct access
defined('_JEXEC') or die();
?>
<!--

Changelog
------------
This is a non-exhaustive (but still near complete) changelog for
the JFirePHP plugin for Joomla 1.5, including beta and release candidate versions.
Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

JFirePHP 1.0.1

31-January-2010 fxstein
# [#19590] Missing language file removed from manifest
# [#19590] Missing quotes on JFIREPHP define

JFirePHP 1.0.0

30-January-2010 fxstein
+ [#19590] Initial version

-->