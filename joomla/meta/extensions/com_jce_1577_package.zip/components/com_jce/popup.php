<?php
  /**
	* @version		$Id: popup.php 140 2009-06-27 11:53:32Z happynoodleboy $
	* @package		Joomla Content Editor (JCE)
	* @copyright	Copyright (C) 2005 - 2009 Ryan Demmer. All rights reserved.
	* @license		GNU/GPL
	* JCE is free software. This version may have been modified pursuant
	* to the GNU General Public License, and as distributed it includes or
	* is derivative of works licensed under the GNU General Public License or
	* other free or open source software licenses.
	*/	
	defined('_JEXEC') or die('Restricted access');
	
	JError::raiseError(403, JText::_('Restricted access'));
?>